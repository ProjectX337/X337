from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from core.planner.architecture_selector import ArchitectureCandidate
from core.planner.capability_match import CapabilityMatch
from core.planner.models import (
    Intent,
    ParsedPrompt,
    TechnologyPlan,
)
from core.planner.stack_builder import ArchitectureStack
from core.spec.project_spec import ProjectSpec
from core.spec.ui_spec import UISpec
from core.spec.models.feature_spec import FeatureSpec
from core.spec.models.design_spec import DesignSpec
from core.knowledge.product_profile import ProductProfile


@dataclass(slots=True)
class PlanningContext:
    """
    Shared planning state for the planning pipeline.
    """

    prompt: str

    parsed: ParsedPrompt | None = None

    intent: Intent | None = None

    capabilities: list[CapabilityMatch] = field(
        default_factory=list
    )

    features: list[str] = field(
        default_factory=list
    )

    architecture_candidates: list[ArchitectureCandidate] = field(
        default_factory=list
    )

    stack: ArchitectureStack | None = None

    technologies: TechnologyPlan | None = None

    project_spec: ProjectSpec | None = None

    ui_spec: UISpec | None = None

    feature_models: list[FeatureSpec] = field(
        default_factory=list
    )

    design_spec: DesignSpec | None = None

    task_graph: Any = None



    product_profile: ProductProfile | None = None
