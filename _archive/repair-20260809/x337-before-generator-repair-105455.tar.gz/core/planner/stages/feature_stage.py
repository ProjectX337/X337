from __future__ import annotations

from core.cognition.cognitive_state import CognitiveState
from core.planner.feature_planner import FeaturePlanner
from core.planner.stages.base_stage import PlanningStage


class FeatureStage(PlanningStage):
    """
    Creates canonical FeatureSpec objects from capability matches.
    """

    requires = {
        "parsed",
        "capabilities",
    }

    provides = {
        "feature_models",
    }

    def __init__(self) -> None:
        self.planner = FeaturePlanner()

    def run(
        self,
        context: CognitiveState,
    ) -> None:

        context.feature_models = self.planner.plan(
            parsed=context.parsed,
            capabilities=context.capabilities,
        )
