from __future__ import annotations

from core.planner.capability_match import CapabilityMatch
from core.planner.models import ParsedPrompt
from core.spec.models.feature_spec import FeatureSpec


class FeaturePlanner:
    """
    Converts canonical capability matches into canonical FeatureSpec objects.

    Pipeline:

        CapabilityMatch[]
              ↓
          FeatureSpec[]
              ↓
        downstream planners
    """

    def __init__(self) -> None:
        pass

    # ---------------------------------------------------------
    # Capability → FeatureSpec
    # ---------------------------------------------------------

    def _to_feature_spec(
        self,
        match: CapabilityMatch,
    ) -> FeatureSpec:

        capability = match.capability

        metadata = dict(
            capability.metadata
        )

        metadata.update(
            {
                "capability": capability.name,
                "capability_score": match.score,
                "capability_confidence": match.confidence,
                "dependencies": list(
                    capability.depends_on
                ),
                "implied_capabilities": list(
                    capability.implies
                ),
                "conflicts": list(
                    capability.conflicts_with
                ),
                "technologies": list(
                    capability.technologies
                ),
                "required_roles": list(
                    capability.required_roles
                ),
            }
        )

        routes = [
            f"/{page.lower().replace(' ', '-')}"
            for page in capability.pages
        ]

        return FeatureSpec(
            name=capability.name,
            slug=capability.slug,
            description=capability.description,
            routes=routes,
            pages=list(
                capability.pages
            ),
            components=list(
                capability.components
            ),
            state=[],
            api_contracts=list(
                capability.api_endpoints
            ),
            metadata=metadata,
        )

    # ---------------------------------------------------------
    # Main planner
    # ---------------------------------------------------------

    def plan(
        self,
        *,
        parsed: ParsedPrompt | None = None,
        capabilities: list[CapabilityMatch] | None = None,
        prompt: str | None = None,
    ) -> list[FeatureSpec]:

        matches = capabilities or []

        return [
            self._to_feature_spec(match)
            for match in matches
        ]

    # ---------------------------------------------------------
    # Compatibility adapter
    # ---------------------------------------------------------

    def plan_application(
        self,
        parsed: ParsedPrompt | None = None,
        capabilities: list[CapabilityMatch] | None = None,
        prompt: str | None = None,
    ) -> dict:

        features = self.plan(
            parsed=parsed,
            capabilities=capabilities,
            prompt=prompt,
        )

        pages = []
        components = []
        services = []

        for feature in features:

            for index, page_name in enumerate(
                feature.pages
            ):

                route = (
                    feature.routes[index]
                    if index < len(feature.routes)
                    else f"/{page_name.lower().replace(' ', '-')}"
                )

                pages.append(
                    {
                        "name": page_name,
                        "route": route,
                        "components": list(
                            feature.components
                        ),
                    }
                )

            components.extend(
                feature.components
            )

            services.extend(
                feature.api_contracts
            )

        return {
            "features": features,
            "pages": pages,
            "components": sorted(
                set(components)
            ),
            "services": sorted(
                set(services)
            ),
        }
